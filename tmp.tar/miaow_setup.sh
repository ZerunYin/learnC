export MIAOW_SRC="/home/ICer/gpu/miaow-master/src"
export MIAOW_RTL="${MIAOW_SRC}/verilog/rtl"
