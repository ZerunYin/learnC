#!/bin/perl

use strict;

# print $ARGV[0];
open FH, "<$ARGV[0]" or die;

open RES, ">$ARGV[0]_vcs";

for (<FH>) {
    chomp;
    if (/\${(.+)}/) {
        my $env_value = $ENV{$1};
        # print $env_value, "\n";
        s/\${(.+)}/$env_value/;
        print RES "$_\n";
    }
}
close FH;
close RES;
